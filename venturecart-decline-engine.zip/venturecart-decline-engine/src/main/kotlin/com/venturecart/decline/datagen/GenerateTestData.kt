package com.venturecart.decline.datagen

import com.venturecart.decline.model.DeclineCodes
import java.io.File
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.random.Random

/**
 * Generates a realistic, reproducible 60-day transaction dataset for VentureCart
 * with several deliberate patterns baked in, so the analysis engine has real
 * signal to find:
 *
 *  1. GlobalPay authorizes far worse than the other two PSPs overall, and its
 *     rate collapses further specifically on weekends.
 *  2. All PSPs see an authorization dip between 00:00-03:59 UTC (issuer
 *     timeouts spike -> decline code 91).
 *  3. Mastercard authorizes noticeably worse than Visa across every PSP.
 *  4. GlobalPay + Brazil + weekend skews heavily toward code 51
 *     (insufficient funds), a soft/recoverable decline.
 *
 * Run with: ./gradlew generateData
 * Output:   test-data/transactions.csv
 */

private const val SEED = 42L
private const val DAYS = 60
private const val RECORDS_PER_DAY = 200 // -> 12,000 total records
private val START_DATE: LocalDate = LocalDate.of(2026, 5, 1)

private data class CountryInfo(val name: String, val currency: String, val weight: Double, val isLatam: Boolean)

private val COUNTRIES = listOf(
    CountryInfo("Brazil", "BRL", 0.30, true),
    CountryInfo("Mexico", "MXN", 0.20, true),
    CountryInfo("Argentina", "ARS", 0.15, true),
    CountryInfo("Colombia", "COP", 0.10, true),
    CountryInfo("Spain", "EUR", 0.15, false),
    CountryInfo("Germany", "EUR", 0.10, false)
)

private val CARD_TYPE_WEIGHTS = listOf("Visa" to 0.60, "Mastercard" to 0.30, "Amex" to 0.10)

// Base authorization probability per PSP before any contextual adjustments
// (weekend/night/card-type penalties below pull the realized blended rate
// down further -- these bases are picked so the final blended rate lands in
// the ~60-65% approved range called for in the brief).
private val BASE_AUTH_RATE = mapOf(
    "GlobalPay" to 0.45,
    "PayConnect" to 0.79,
    "MercadoProcessing" to 0.77
)

private val LATAM_PSP_WEIGHTS = listOf("MercadoProcessing" to 0.45, "GlobalPay" to 0.35, "PayConnect" to 0.20)
private val EUROPE_PSP_WEIGHTS = listOf("PayConnect" to 0.55, "GlobalPay" to 0.30, "MercadoProcessing" to 0.15)

private const val WEEKEND_GLOBALPAY_PENALTY = 0.15
private const val NIGHT_HOUR_PENALTY = 0.10
private const val MASTERCARD_PENALTY = 0.12
private const val AMEX_BONUS = 0.02

private fun <T> weightedPick(random: Random, items: List<Pair<T, Double>>): T {
    val total = items.sumOf { it.second }
    var r = random.nextDouble() * total
    for ((item, w) in items) {
        if (r < w) return item
        r -= w
    }
    return items.last().first
}

private fun weightedHour(random: Random): Int {
    // Heavier weight on daytime/evening hours, but a real tail overnight so
    // the 00:00-03:59 issuer-timeout pattern has enough volume to be detected.
    val weights = (0..23).map { h ->
        h to when (h) {
            in 0..3 -> 3.0
            in 4..6 -> 2.5
            in 7..21 -> 6.0
            else -> 3.5
        }
    }
    return weightedPick(random, weights)
}

private fun generateBin(cardType: String, random: Random): String = when (cardType) {
    "Visa" -> "4" + (1..5).joinToString("") { random.nextInt(0, 10).toString() }
    "Mastercard" -> {
        val prefix = (51..55).random(random)
        "$prefix" + (1..4).joinToString("") { random.nextInt(0, 10).toString() }
    }
    "Amex" -> {
        val prefix = listOf("34", "37").random(random)
        prefix + (1..4).joinToString("") { random.nextInt(0, 10).toString() }
    }
    else -> "400000"
}

private fun pickDeclineCode(random: Random, hour: Int, psp: String, country: String, isWeekend: Boolean): String {
    val weights = linkedMapOf(
        "51" to 30.0, // insufficient funds - soft
        "05" to 20.0, // do not honor - soft
        "91" to 15.0, // issuer timeout - soft
        "65" to 10.0, // activity limit exceeded - soft
        "14" to 10.0, // invalid card number - hard
        "41" to 5.0,  // lost card - hard
        "54" to 10.0  // expired card - hard
    )
    if (hour in 0..3) {
        weights["91"] = 45.0 // pattern #2: overnight issuer timeouts spike
    }
    if (psp == "GlobalPay" && country == "Brazil" && isWeekend) {
        weights["51"] = weights.getValue("51") + 40.0 // pattern #4
    }
    val total = weights.values.sum()
    var r = random.nextDouble() * total
    for ((code, w) in weights) {
        if (r < w) return code
        r -= w
    }
    return weights.keys.last()
}

fun main() {
    val random = Random(SEED)
    val outFile = File("test-data/transactions.csv")
    outFile.parentFile?.mkdirs()

    var txCounter = 0
    var approvedCount = 0
    var declinedCount = 0
    val pspTotals = mutableMapOf<String, Pair<Int, Int>>() // psp -> (total, approved)
    val cardTotals = mutableMapOf<String, Pair<Int, Int>>()
    var globalPayWeekendTotal = 0; var globalPayWeekendApproved = 0
    var globalPayWeekdayTotal = 0; var globalPayWeekdayApproved = 0
    var nightTotal = 0; var nightApproved = 0
    var dayTotal = 0; var dayApproved = 0

    outFile.bufferedWriter().use { writer ->
        writer.write("transaction_id,timestamp,amount,currency,country,psp,card_type,bin,status,decline_reason_code,decline_type")
        writer.newLine()

        for (dayOffset in 0 until DAYS) {
            val date = START_DATE.plusDays(dayOffset.toLong())
            val isWeekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY

            repeat(RECORDS_PER_DAY) {
                val hour = weightedHour(random)
                val minute = random.nextInt(0, 60)
                val second = random.nextInt(0, 60)
                val timestamp = date.atTime(hour, minute, second).toInstant(ZoneOffset.UTC)

                val country = weightedPick(random, COUNTRIES.map { it.name to it.weight })
                val countryInfo = COUNTRIES.first { it.name == country }
                val pspWeights = if (countryInfo.isLatam) LATAM_PSP_WEIGHTS else EUROPE_PSP_WEIGHTS
                val psp = weightedPick(random, pspWeights)
                val cardType = weightedPick(random, CARD_TYPE_WEIGHTS)
                val bin = generateBin(cardType, random)
                val amount = String.format("%.2f", random.nextDouble(15.0, 480.0))

                var authProb = BASE_AUTH_RATE.getValue(psp)
                if (psp == "GlobalPay" && isWeekend) authProb -= WEEKEND_GLOBALPAY_PENALTY
                if (hour in 0..3) authProb -= NIGHT_HOUR_PENALTY
                authProb += when (cardType) {
                    "Mastercard" -> -MASTERCARD_PENALTY
                    "Amex" -> AMEX_BONUS
                    else -> 0.0
                }
                authProb = authProb.coerceIn(0.05, 0.95)

                val approved = random.nextDouble() < authProb
                txCounter++

                val (status, code, type) = if (approved) {
                    Triple("approved", "", "")
                } else {
                    val c = pickDeclineCode(random, hour, psp, country, isWeekend)
                    Triple("declined", c, DeclineCodes.typeOf(c).name.lowercase())
                }

                writer.write(
                    listOf(
                        "TXN-%06d".format(txCounter),
                        timestamp.toString(),
                        amount,
                        countryInfo.currency,
                        country,
                        psp,
                        cardType,
                        bin,
                        status,
                        code,
                        type
                    ).joinToString(",")
                )
                writer.newLine()

                // -- stats bookkeeping for the console summary --
                if (approved) approvedCount++ else declinedCount++
                val (pTot, pApp) = pspTotals.getOrDefault(psp, 0 to 0)
                pspTotals[psp] = (pTot + 1) to (pApp + if (approved) 1 else 0)
                val (cTot, cApp) = cardTotals.getOrDefault(cardType, 0 to 0)
                cardTotals[cardType] = (cTot + 1) to (cApp + if (approved) 1 else 0)
                if (psp == "GlobalPay") {
                    if (isWeekend) {
                        globalPayWeekendTotal++; if (approved) globalPayWeekendApproved++
                    } else {
                        globalPayWeekdayTotal++; if (approved) globalPayWeekdayApproved++
                    }
                }
                if (hour in 0..3) {
                    nightTotal++; if (approved) nightApproved++
                } else {
                    dayTotal++; if (approved) dayApproved++
                }
            }
        }
    }

    fun pct(a: Int, b: Int) = if (b == 0) 0.0 else Math.round((a.toDouble() / b) * 10000) / 100.0

    println("Generated $txCounter transactions -> ${outFile.path}")
    println("=".repeat(60))
    println("Overall auth rate: ${pct(approvedCount, txCounter)}% ($approvedCount approved / $declinedCount declined)")
    println()
    println("By PSP:")
    pspTotals.toList().sortedBy { pct(it.second.second, it.second.first) }.forEach { (psp, stats) ->
        println("  $psp: ${pct(stats.second, stats.first)}% (n=${stats.first})")
    }
    println()
    println("By card type:")
    cardTotals.toList().sortedBy { pct(it.second.second, it.second.first) }.forEach { (card, stats) ->
        println("  $card: ${pct(stats.second, stats.first)}% (n=${stats.first})")
    }
    println()
    println("GlobalPay weekday vs weekend: ${pct(globalPayWeekdayApproved, globalPayWeekdayTotal)}% vs ${pct(globalPayWeekendApproved, globalPayWeekendTotal)}%")
    println("Overnight (00:00-03:59) vs rest of day: ${pct(nightApproved, nightTotal)}% vs ${pct(dayApproved, dayTotal)}%")
    println("=".repeat(60))
    println("Start the API and it will auto-load this file, or POST /api/ingest {\"filePath\": \"test-data/transactions.csv\"}")
}
