package com.venturecart.decline.model

import java.time.Instant

enum class TxStatus { APPROVED, DECLINED }

enum class DeclineType { SOFT, HARD }

/**
 * A single payment attempt as ingested from VentureCart's export.
 *
 * decline_reason_code / decline_type are null for approved transactions.
 */
data class Transaction(
    val transactionId: String,
    val timestamp: Instant,
    val amount: Double,
    val currency: String,
    val country: String,
    val psp: String,
    val cardType: String,
    val bin: String,
    val status: TxStatus,
    val declineReasonCode: String?,
    val declineType: DeclineType?
)

/**
 * Reference table for the decline reason codes used in this system.
 * Soft = potentially recoverable via retry / retry logic / alternate routing.
 * Hard = permanent failure, retrying will not help.
 *
 * This mapping is the source of truth for both the data generator and the
 * analysis engine, so ingestion and analysis never disagree about a code's type.
 */
object DeclineCodes {
    data class CodeInfo(val description: String, val type: DeclineType)

    val REFERENCE: Map<String, CodeInfo> = mapOf(
        "51" to CodeInfo("Insufficient funds", DeclineType.SOFT),
        "05" to CodeInfo("Do not honor", DeclineType.SOFT),
        "91" to CodeInfo("Issuer or switch inoperative (timeout)", DeclineType.SOFT),
        "65" to CodeInfo("Activity count limit exceeded", DeclineType.SOFT),
        "14" to CodeInfo("Invalid card number", DeclineType.HARD),
        "41" to CodeInfo("Lost card", DeclineType.HARD),
        "54" to CodeInfo("Expired card", DeclineType.HARD)
    )

    fun typeOf(code: String): DeclineType =
        REFERENCE[code]?.type ?: DeclineType.HARD

    fun descriptionOf(code: String): String =
        REFERENCE[code]?.description ?: "Unknown reason code"
}
