package com.venturecart.decline.repository

import com.venturecart.decline.model.DeclineType
import com.venturecart.decline.model.Transaction
import com.venturecart.decline.model.TxStatus
import java.io.File
import java.time.Instant
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/**
 * Simple in-memory store for transactions.
 *
 * For a take-home / analysis-engine service, an in-memory list is a deliberate
 * choice over standing up Postgres/Mongo: it keeps setup to "clone + run", and
 * Kotlin's collection operations (groupBy, filter, sumOf, etc.) comfortably
 * handle tens of thousands of records with room to spare for a service like
 * this. Swapping this for a real database later only touches this file.
 */
object TransactionRepository {

    private val store = CopyOnWriteArrayList<Transaction>()
    private val recordsLoaded = AtomicInteger(0)
    private val recordsRejected = AtomicInteger(0)
    var lastLoadedFile: String? = null
        private set

    fun all(): List<Transaction> = store

    fun clear() {
        store.clear()
        recordsLoaded.set(0)
        recordsRejected.set(0)
    }

    fun count(): Int = store.size

    fun ingestionStats(): Pair<Int, Int> = recordsLoaded.get() to recordsRejected.get()

    /**
     * Loads transactions from a CSV file with header:
     * transaction_id,timestamp,amount,currency,country,psp,card_type,bin,status,decline_reason_code,decline_type
     *
     * timestamp is expected in ISO-8601 (e.g. 2026-05-01T14:32:07Z).
     * decline_reason_code / decline_type may be empty for approved rows.
     */
    fun loadFromCsv(path: String, replaceExisting: Boolean = true): Int {
        val file = File(path)
        require(file.exists()) { "CSV file not found at $path" }

        if (replaceExisting) clear()

        val loaded = mutableListOf<Transaction>()
        var rejected = 0

        file.bufferedReader().useLines { lines ->
            lines.drop(1).forEachIndexed { idx, line ->
                if (line.isBlank()) return@forEachIndexed
                try {
                    val cols = line.split(",")
                    require(cols.size >= 11) { "expected 11 columns, got ${cols.size}" }

                    val status = TxStatus.valueOf(cols[8].trim().uppercase())
                    val rawDeclineCode = cols[9].trim()
                    val rawDeclineType = cols[10].trim()

                    loaded += Transaction(
                        transactionId = cols[0].trim(),
                        timestamp = Instant.parse(cols[1].trim()),
                        amount = cols[2].trim().toDouble(),
                        currency = cols[3].trim(),
                        country = cols[4].trim(),
                        psp = cols[5].trim(),
                        cardType = cols[6].trim(),
                        bin = cols[7].trim(),
                        status = status,
                        declineReasonCode = rawDeclineCode.ifEmpty { null },
                        declineType = rawDeclineType.ifEmpty { null }?.let { DeclineType.valueOf(it.uppercase()) }
                    )
                } catch (e: Exception) {
                    rejected++
                    // Row-level failures shouldn't kill a 10k+ row ingest; we
                    // surface the count instead so bad rows are visible but
                    // not silently swallowed.
                    System.err.println("Skipping malformed row ${idx + 2}: ${e.message}")
                }
            }
        }

        store.addAll(loaded)
        recordsLoaded.set(loaded.size)
        recordsRejected.set(rejected)
        lastLoadedFile = path
        return loaded.size
    }
}
