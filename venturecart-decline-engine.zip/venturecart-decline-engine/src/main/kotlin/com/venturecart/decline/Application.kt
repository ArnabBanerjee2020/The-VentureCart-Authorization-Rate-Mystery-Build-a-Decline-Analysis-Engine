package com.venturecart.decline

import com.venturecart.decline.dto.ErrorResponse
import com.venturecart.decline.repository.TransactionRepository
import com.venturecart.decline.routes.declineAnalysisRoutes
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.callloging.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.plugins.cors.routing.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.json.Json
import java.io.File

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    embeddedServer(Netty, port = port, host = "0.0.0.0", module = Application::module)
        .start(wait = true)
}

fun Application.module() {
    install(ContentNegotiation) {
        json(Json {
            prettyPrint = true
            ignoreUnknownKeys = true
        })
    }

    install(CallLogging)

    install(CORS) {
        anyHost()
        allowHeader(HttpHeaders.ContentType)
        allowMethod(HttpMethod.Get)
        allowMethod(HttpMethod.Post)
    }

    install(StatusPages) {
        exception<Throwable> { call, cause ->
            call.respond(HttpStatusCode.InternalServerError, ErrorResponse(cause.message ?: "Unexpected error"))
        }
    }

    // Convenience auto-load: if the generated dataset is sitting where the
    // README tells you to put it, boot with data already queryable instead
    // of forcing a manual /api/ingest call first.
    val defaultDataset = "test-data/transactions.csv"
    if (File(defaultDataset).exists()) {
        val count = TransactionRepository.loadFromCsv(defaultDataset)
        log.info("Auto-loaded $count transactions from $defaultDataset")
    } else {
        log.info("No dataset found at $defaultDataset — POST /api/ingest to load one.")
    }

    routing {
        declineAnalysisRoutes()
    }
}
