package com.venturecart.decline.routes

import com.venturecart.decline.dto.ErrorResponse
import com.venturecart.decline.dto.IngestResponse
import com.venturecart.decline.repository.TransactionRepository
import com.venturecart.decline.service.HypothesisService
import com.venturecart.decline.service.MetricsService
import com.venturecart.decline.service.PatternService
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.serialization.Serializable
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@Serializable
data class IngestRequest(val filePath: String)

/**
 * Parses an optional date-range query param into an Instant.
 * Accepts either a full ISO instant (2026-05-01T00:00:00Z) or a plain date
 * (2026-05-01), since "compare week 1 vs week 8" style requests are far more
 * naturally expressed as plain dates. `endOfDay` pushes plain dates to
 * 23:59:59 so `to=2026-05-01` includes that whole day.
 */
private fun parseInstantParam(raw: String?, endOfDay: Boolean = false): Instant? {
    if (raw.isNullOrBlank()) return null
    return try {
        Instant.parse(raw)
    } catch (e: Exception) {
        val date = LocalDate.parse(raw)
        if (endOfDay) date.atTime(23, 59, 59).toInstant(ZoneOffset.UTC)
        else date.atStartOfDay(ZoneOffset.UTC).toInstant()
    }
}

fun Route.declineAnalysisRoutes() {

    route("/api") {

        get("/health") {
            call.respond(mapOf("status" to "ok", "transactionsLoaded" to TransactionRepository.count()))
        }

        // --- Ingestion -----------------------------------------------------
        post("/ingest") {
            val body = call.receive<IngestRequest>()
            try {
                val loaded = TransactionRepository.loadFromCsv(body.filePath)
                val (_, rejected) = TransactionRepository.ingestionStats()
                call.respond(
                    IngestResponse(
                        filePath = body.filePath,
                        recordsLoaded = loaded,
                        recordsRejected = rejected,
                        totalRecordsInStore = TransactionRepository.count()
                    )
                )
            } catch (e: Exception) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Failed to ingest file: ${e.message}"))
            }
        }

        // --- Metrics ---------------------------------------------------------
        route("/metrics") {

            get("/summary") {
                val from = parseInstantParam(call.request.queryParameters["from"])
                val to = parseInstantParam(call.request.queryParameters["to"], endOfDay = true)
                call.respond(MetricsService.summary(TransactionRepository.all(), from, to))
            }

            get("/declines") {
                val from = parseInstantParam(call.request.queryParameters["from"])
                val to = parseInstantParam(call.request.queryParameters["to"], endOfDay = true)
                call.respond(MetricsService.declineAnalysis(TransactionRepository.all(), from, to))
            }

            get("/patterns") {
                val from = parseInstantParam(call.request.queryParameters["from"])
                val to = parseInstantParam(call.request.queryParameters["to"], endOfDay = true)
                call.respond(PatternService.analyze(TransactionRepository.all(), from, to))
            }

            get("/hypotheses") {
                val from = parseInstantParam(call.request.queryParameters["from"])
                val to = parseInstantParam(call.request.queryParameters["to"], endOfDay = true)
                call.respond(HypothesisService.generate(TransactionRepository.all(), from, to))
            }
        }
    }
}
