package com.venturecart.decline.dto

import kotlinx.serialization.Serializable

@Serializable
data class DateRangeDto(val from: String?, val to: String?, val transactionCount: Int)

@Serializable
data class AuthRateBucket(
    val key: String,
    val totalTransactions: Int,
    val approved: Int,
    val declined: Int,
    val authRatePct: Double
)

@Serializable
data class SummaryResponse(
    val range: DateRangeDto,
    val overall: AuthRateBucket,
    val byPsp: List<AuthRateBucket>,
    val byCountry: List<AuthRateBucket>,
    val byCardType: List<AuthRateBucket>
)

@Serializable
data class DeclineTypeBreakdown(
    val totalDeclines: Int,
    val softDeclines: Int,
    val hardDeclines: Int,
    val softDeclinePct: Double,
    val hardDeclinePct: Double,
    val potentiallyRecoverableRevenueShare: String
)

@Serializable
data class DeclineReasonEntry(
    val code: String,
    val description: String,
    val type: String,
    val count: Int,
    val pctOfAllDeclines: Double
)

@Serializable
data class DeclineAnalysisResponse(
    val range: DateRangeDto,
    val declineTypeBreakdown: DeclineTypeBreakdown,
    val topDeclineReasons: List<DeclineReasonEntry>
)

@Serializable
data class TimeBucketStat(
    val bucket: String,
    val totalTransactions: Int,
    val authRatePct: Double,
    val deltaVsBaselinePct: Double,
    val significant: Boolean
)

@Serializable
data class PatternResponse(
    val range: DateRangeDto,
    val baselineAuthRatePct: Double,
    val significanceThresholdPct: Double,
    val byHourOfDay: List<TimeBucketStat>,
    val byDayOfWeek: List<TimeBucketStat>,
    val notableFindings: List<String>
)

@Serializable
data class Hypothesis(
    val headline: String,
    val evidence: String,
    val recommendation: String
)

@Serializable
data class HypothesisResponse(
    val range: DateRangeDto,
    val hypotheses: List<Hypothesis>
)

@Serializable
data class IngestResponse(
    val filePath: String,
    val recordsLoaded: Int,
    val recordsRejected: Int,
    val totalRecordsInStore: Int
)

@Serializable
data class ErrorResponse(val error: String)
