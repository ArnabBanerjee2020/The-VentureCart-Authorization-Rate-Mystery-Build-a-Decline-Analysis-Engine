package com.venturecart.decline.service

import com.venturecart.decline.dto.DateRangeDto
import com.venturecart.decline.dto.PatternResponse
import com.venturecart.decline.dto.TimeBucketStat
import com.venturecart.decline.model.Transaction
import com.venturecart.decline.model.TxStatus
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.round

/**
 * Flags hour-of-day / day-of-week buckets whose auth rate deviates from the
 * overall baseline by more than [SIGNIFICANCE_THRESHOLD_PCT] points, and
 * requires a minimum bucket size so a handful of unlucky transactions in a
 * quiet hour doesn't get reported as a "pattern".
 */
object PatternService {

    private const val SIGNIFICANCE_THRESHOLD_PCT = 8.0
    private const val MIN_BUCKET_SIZE = 30

    private fun pct(numerator: Int, denominator: Int): Double =
        if (denominator == 0) 0.0 else round((numerator.toDouble() / denominator) * 10000) / 100.0

    private fun authRate(txs: List<Transaction>): Double =
        pct(txs.count { it.status == TxStatus.APPROVED }, txs.size)

    fun analyze(transactions: List<Transaction>, from: Instant?, to: Instant?): PatternResponse {
        val scoped = MetricsService.filterByRange(transactions, from, to)
        val baseline = authRate(scoped)

        val byHour = (0..23).map { hour ->
            val txs = scoped.filter { it.timestamp.atZone(ZoneOffset.UTC).hour == hour }
            toBucketStat("%02d:00-%02d:59".format(hour, hour), txs, baseline)
        }

        val dayOrder = listOf(
            java.time.DayOfWeek.MONDAY, java.time.DayOfWeek.TUESDAY, java.time.DayOfWeek.WEDNESDAY,
            java.time.DayOfWeek.THURSDAY, java.time.DayOfWeek.FRIDAY, java.time.DayOfWeek.SATURDAY,
            java.time.DayOfWeek.SUNDAY
        )
        val byDay = dayOrder.map { dow ->
            val txs = scoped.filter { it.timestamp.atZone(ZoneOffset.UTC).dayOfWeek == dow }
            val label = dow.getDisplayName(TextStyle.FULL, Locale.ENGLISH)
            toBucketStat(label, txs, baseline)
        }

        val findings = mutableListOf<String>()
        byHour.filter { it.significant }.forEach {
            val direction = if (it.deltaVsBaselinePct < 0) "drops" else "jumps"
            findings += "Authorization rate $direction ${"%.1f".format(kotlin.math.abs(it.deltaVsBaselinePct))} " +
                "points during ${it.bucket} (n=${it.totalTransactions}) vs. the %.1f%% overall baseline.".format(baseline)
        }
        byDay.filter { it.significant }.forEach {
            val direction = if (it.deltaVsBaselinePct < 0) "drops" else "jumps"
            findings += "Authorization rate $direction ${"%.1f".format(kotlin.math.abs(it.deltaVsBaselinePct))} " +
                "points on ${it.bucket} (n=${it.totalTransactions}) vs. the %.1f%% overall baseline.".format(baseline)
        }
        if (findings.isEmpty()) {
            findings += "No time-based bucket deviated from baseline by more than " +
                "$SIGNIFICANCE_THRESHOLD_PCT points with at least $MIN_BUCKET_SIZE transactions."
        }

        return PatternResponse(
            range = MetricsService.rangeDto(scoped, from, to),
            baselineAuthRatePct = baseline,
            significanceThresholdPct = SIGNIFICANCE_THRESHOLD_PCT,
            byHourOfDay = byHour,
            byDayOfWeek = byDay,
            notableFindings = findings
        )
    }

    private fun toBucketStat(label: String, txs: List<Transaction>, baseline: Double): TimeBucketStat {
        val rate = authRate(txs)
        val delta = round((rate - baseline) * 100) / 100.0
        val significant = txs.size >= MIN_BUCKET_SIZE && kotlin.math.abs(delta) >= SIGNIFICANCE_THRESHOLD_PCT
        return TimeBucketStat(
            bucket = label,
            totalTransactions = txs.size,
            authRatePct = rate,
            deltaVsBaselinePct = delta,
            significant = significant
        )
    }
}
