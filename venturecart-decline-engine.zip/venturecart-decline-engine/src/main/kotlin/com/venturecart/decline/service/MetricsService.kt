package com.venturecart.decline.service

import com.venturecart.decline.dto.*
import com.venturecart.decline.model.DeclineCodes
import com.venturecart.decline.model.DeclineType
import com.venturecart.decline.model.Transaction
import com.venturecart.decline.model.TxStatus
import java.time.Instant
import kotlin.math.round

object MetricsService {

    /** Filters transactions to an inclusive [from, to] window. Nulls mean "unbounded". */
    fun filterByRange(transactions: List<Transaction>, from: Instant?, to: Instant?): List<Transaction> =
        transactions.filter { tx ->
            (from == null || !tx.timestamp.isBefore(from)) &&
                (to == null || !tx.timestamp.isAfter(to))
        }

    fun rangeDto(transactions: List<Transaction>, from: Instant?, to: Instant?): DateRangeDto =
        DateRangeDto(from?.toString(), to?.toString(), transactions.size)

    private fun pct(numerator: Int, denominator: Int): Double =
        if (denominator == 0) 0.0 else round((numerator.toDouble() / denominator) * 10000) / 100.0

    fun bucket(key: String, txs: List<Transaction>): AuthRateBucket {
        val approved = txs.count { it.status == TxStatus.APPROVED }
        val declined = txs.count { it.status == TxStatus.DECLINED }
        return AuthRateBucket(
            key = key,
            totalTransactions = txs.size,
            approved = approved,
            declined = declined,
            authRatePct = pct(approved, txs.size)
        )
    }

    fun summary(transactions: List<Transaction>, from: Instant?, to: Instant?): SummaryResponse {
        val scoped = filterByRange(transactions, from, to)

        val byPsp = scoped.groupBy { it.psp }
            .map { (key, txs) -> bucket(key, txs) }
            .sortedBy { it.authRatePct }

        val byCountry = scoped.groupBy { it.country }
            .map { (key, txs) -> bucket(key, txs) }
            .sortedBy { it.authRatePct }

        val byCardType = scoped.groupBy { it.cardType }
            .map { (key, txs) -> bucket(key, txs) }
            .sortedBy { it.authRatePct }

        return SummaryResponse(
            range = rangeDto(scoped, from, to),
            overall = bucket("overall", scoped),
            byPsp = byPsp,
            byCountry = byCountry,
            byCardType = byCardType
        )
    }

    fun declineAnalysis(transactions: List<Transaction>, from: Instant?, to: Instant?): DeclineAnalysisResponse {
        val scoped = filterByRange(transactions, from, to)
        val declines = scoped.filter { it.status == TxStatus.DECLINED }

        val soft = declines.count { it.declineType == DeclineType.SOFT }
        val hard = declines.count { it.declineType == DeclineType.HARD }

        val declineValueTotal = declines.sumOf { it.amount }
        val softValue = declines.filter { it.declineType == DeclineType.SOFT }.sumOf { it.amount }
        val recoverableShare = if (declineValueTotal == 0.0) "$0.00 (0.0% of declined value)"
        else {
            val sharePct = round((softValue / declineValueTotal) * 10000) / 100.0
            "%.2f (%.1f%% of declined transaction value)".format(softValue, sharePct)
        }

        val breakdown = DeclineTypeBreakdown(
            totalDeclines = declines.size,
            softDeclines = soft,
            hardDeclines = hard,
            softDeclinePct = pct(soft, declines.size),
            hardDeclinePct = pct(hard, declines.size),
            potentiallyRecoverableRevenueShare = recoverableShare
        )

        val topReasons = declines
            .filter { it.declineReasonCode != null }
            .groupBy { it.declineReasonCode!! }
            .map { (code, txs) ->
                DeclineReasonEntry(
                    code = code,
                    description = DeclineCodes.descriptionOf(code),
                    type = DeclineCodes.typeOf(code).name,
                    count = txs.size,
                    pctOfAllDeclines = pct(txs.size, declines.size)
                )
            }
            .sortedByDescending { it.count }

        return DeclineAnalysisResponse(
            range = rangeDto(scoped, from, to),
            declineTypeBreakdown = breakdown,
            topDeclineReasons = topReasons
        )
    }
}
