package com.venturecart.decline.service

import com.venturecart.decline.dto.Hypothesis
import com.venturecart.decline.dto.HypothesisResponse
import com.venturecart.decline.model.DeclineCodes
import com.venturecart.decline.model.Transaction
import com.venturecart.decline.model.TxStatus
import java.time.Instant
import kotlin.math.abs
import kotlin.math.round

/**
 * Generates root-cause hypotheses purely from the computed metrics for the
 * requested range -- nothing here is hardcoded to a specific PSP/country/card
 * name, so it produces different (and correctly empty) output on different
 * slices of data.
 */
object HypothesisService {

    private const val MIN_SAMPLE = 50

    private fun pct(n: Int, d: Int): Double = if (d == 0) 0.0 else round((n.toDouble() / d) * 10000) / 100.0
    private fun authRate(txs: List<Transaction>): Double = pct(txs.count { it.status == TxStatus.APPROVED }, txs.size)

    fun generate(transactions: List<Transaction>, from: Instant?, to: Instant?): HypothesisResponse {
        val scoped = MetricsService.filterByRange(transactions, from, to)
        val overallRate = authRate(scoped)
        val hypotheses = mutableListOf<Hypothesis>()

        // 1) Worst-performing PSP vs. the rest.
        val byPsp = scoped.groupBy { it.psp }.filter { it.value.size >= MIN_SAMPLE }
        byPsp.minByOrNull { authRate(it.value) }?.let { (psp, txs) ->
            val rate = authRate(txs)
            if (overallRate - rate >= 10.0) {
                hypotheses += Hypothesis(
                    headline = "PSP '$psp' is dragging down the blended authorization rate",
                    evidence = "$psp has a %.1f%% auth rate across %d transactions vs. a %.1f%% overall average — a %.1f point gap."
                        .format(rate, txs.size, overallRate, overallRate - rate),
                    recommendation = "Investigate $psp's technical integration (timeouts, stale routing rules, " +
                        "certificate/config drift) and consider shifting volume away from it via smart routing " +
                        "while the issue is root-caused."
                )
            }
        }

        // 2) Card type gap (e.g. Mastercard vs Visa).
        val byCard = scoped.groupBy { it.cardType }.filter { it.value.size >= MIN_SAMPLE }
        if (byCard.size >= 2) {
            val best = byCard.maxByOrNull { authRate(it.value) }!!
            val worst = byCard.minByOrNull { authRate(it.value) }!!
            val gap = authRate(best.value) - authRate(worst.value)
            if (gap >= 10.0 && best.key != worst.key) {
                hypotheses += Hypothesis(
                    headline = "${worst.key} transactions authorize significantly worse than ${best.key}",
                    evidence = "${worst.key} auth rate is %.1f%% (n=%d) vs. %.1f%% (n=%d) for ${best.key} — a %.1f point gap, consistent across PSPs."
                        .format(authRate(worst.value), worst.value.size, authRate(best.value), best.value.size, gap),
                    recommendation = "Check issuer-specific routing/BIN rules and 3-D Secure configuration for " +
                        "${worst.key}; a scheme-level integration issue is more likely than a fraud issue if the " +
                        "gap holds across every PSP and country."
                )
            }
        }

        // 3) Dominant recoverable soft-decline reason, optionally concentrated in one PSP/country/day-type.
        val declines = scoped.filter { it.status == TxStatus.DECLINED && it.declineReasonCode != null }
        val byReason = declines.groupBy { it.declineReasonCode!! }
        byReason.maxByOrNull { it.value.size }?.let { (code, txs) ->
            val shareOfDeclines = pct(txs.size, declines.size)
            if (shareOfDeclines >= 25.0 && txs.size >= MIN_SAMPLE) {
                val type = DeclineCodes.typeOf(code)
                val desc = DeclineCodes.descriptionOf(code)
                val topCountry = txs.groupBy { it.country }.maxByOrNull { it.value.size }
                val countryNote = topCountry?.let {
                    val share = pct(it.value.size, txs.size)
                    if (share >= 40.0) " ${share}% of these are concentrated in ${it.key}." else ""
                } ?: ""
                hypotheses += Hypothesis(
                    headline = "Decline code $code ($desc) is the single biggest contributor to lost revenue",
                    evidence = "$shareOfDeclines% of all declines are code $code, classified as $type.$countryNote",
                    recommendation = if (type.name == "SOFT")
                        "Since this is a soft decline, add automated retry logic (with backoff) or offer an " +
                            "alternate payment method / installments at checkout to recover a meaningful share of it."
                    else
                        "This is a hard decline — retries won't help. Focus on upstream prevention " +
                            "(card verification at entry, expiry-date nudges) rather than retry logic."
                )
            }
        }

        // 4) Weekend vs. weekday gap for the single worst PSP (checks a specific, common real-world pattern).
        val worstPsp = byPsp.minByOrNull { authRate(it.value) }
        worstPsp?.let { (psp, txs) ->
            val weekend = txs.filter {
                val dow = it.timestamp.atZone(java.time.ZoneOffset.UTC).dayOfWeek
                dow == java.time.DayOfWeek.SATURDAY || dow == java.time.DayOfWeek.SUNDAY
            }
            val weekday = txs - weekend.toSet()
            if (weekend.size >= MIN_SAMPLE && weekday.size >= MIN_SAMPLE) {
                val gap = authRate(weekday) - authRate(weekend)
                if (gap >= 10.0) {
                    hypotheses += Hypothesis(
                        headline = "$psp's authorization rate collapses specifically on weekends",
                        evidence = "%.1f%% weekday vs. %.1f%% weekend auth rate for $psp — a %.1f point weekend gap."
                            .format(authRate(weekday), authRate(weekend), gap),
                        recommendation = "Confirm whether $psp has reduced weekend staffing/monitoring, a batch " +
                            "job or issuer maintenance window on weekends, or a routing rule that only applies " +
                            "Mon-Fri."
                    )
                }
            }
        }

        if (hypotheses.isEmpty()) {
            hypotheses += Hypothesis(
                headline = "No single dominant root cause detected in this range",
                evidence = "No PSP, card type, decline code, or weekend/weekday split exceeded the significance " +
                    "thresholds used by this generator for the selected date range.",
                recommendation = "Widen the date range or drill into the /metrics/patterns endpoint for finer-grained " +
                    "hour-of-day analysis."
            )
        }

        return HypothesisResponse(
            range = MetricsService.rangeDto(scoped, from, to),
            hypotheses = hypotheses
        )
    }
}
